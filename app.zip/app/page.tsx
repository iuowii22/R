'use client';
import { useEffect, useRef, useState } from 'react';
import { allLessons } from './curriculum';
import { supabase } from '../lib/supabase';

type Message = { role: 'user' | 'assistant'; content: string };
type TutorReply = { reply?: string; error?: string };
const vocabulary = [
  ['achieve','يحقق','She wants to achieve her goal.'],['improve','يحسّن','Practice helps you improve.'],['although','على الرغم من','Although it was late, we continued.'],['decision','قرار','It was a difficult decision.'],['environment','البيئة','We should protect the environment.'],['reliable','موثوق','We need reliable information.'],['opportunity','فرصة','This is a great opportunity.'],['require','يتطلب','The job requires experience.'],['develop','يطوّر','I want to develop my skills.'],['benefit','فائدة','Exercise has many benefits.'],['challenge','تحدٍ','Learning a language is a challenge.'],['available','متاح','Is this seat available?'],['consider','يعتبر / ينظر في','Please consider my suggestion.'],['increase','يزيد','Prices may increase.'],['reduce','يقلّل','We need to reduce waste.'],['suggest','يقترح','I suggest taking a break.'],['explain','يشرح','Can you explain this rule?'],['experience','خبرة / تجربة','She has work experience.'],['knowledge','معرفة','Knowledge takes time to build.'],['likely','من المرجح','It is likely to rain.'],['instead','بدلًا من ذلك','Walk instead of driving.'],['purpose','غرض / هدف','What is the purpose of this task?'],['avoid','يتجنب','Avoid making the same mistake.'],['compare','يقارن','Compare the two answers.'],['support','يدعم','The evidence supports the idea.'],['evidence','دليل','We need more evidence.'],['accurate','دقيق','The information is accurate.'],['especially','خصوصًا','I enjoy reading, especially history.'],['eventually','في النهاية','Eventually, she found a solution.'],['opinion','رأي','In my opinion, it is useful.'],['afford','يستطيع تحمّل التكلفة','I cannot afford a new laptop.'],['attend','يحضر','I attend class every Monday.'],['behavior','سلوك','Sleep affects behavior.'],['community','مجتمع','The community helped us.'],['confidence','ثقة','Practice builds confidence.'],['deliver','يسلّم / يوصل','They deliver the package today.'],['essential','أساسي','Water is essential for life.'],['flexible','مرن','We need a flexible plan.'],['independent','مستقل','She is an independent learner.'],['maintain','يحافظ على','Maintain a regular study routine.'],['method','طريقة','This method works well.'],['occur','يحدث','Mistakes occur during learning.'],['prevent','يمنع','This can prevent errors.'],['process','عملية','Learning is a gradual process.'],['provide','يوفر','The course provides examples.'],['recognize','يتعرف على','I recognize that word.'],['respond','يرد','Please respond to the question.'],['significant','ملحوظ / مهم','There was a significant change.'],['strategy','استراتيجية','Use a new study strategy.'],['tend','يميل إلى','I tend to study at night.']
] as const;
const listeningTracks = [
  {title:'A1 · A morning routine',level:'A1',text:'Hello, my name is Emma. I wake up at seven every morning. I have breakfast with my family, and then I take the bus to school. My first class starts at nine.',q:'What time does Emma wake up?',options:['At six','At seven','At nine'],answer:1,why:'قالت Emma: I wake up at seven.'},
  {title:'A2 · Making a plan',level:'A2',text:'Hi Omar, would you like to study together this afternoon? I can meet you at the library at four. We should review the grammar first and then practice the vocabulary. Please bring your notebook.',q:'Where will they meet?',options:['At the café','At the library','At school'],answer:1,why:'المكان المذكور هو المكتبة.'},
  {title:'B1 · A delayed train',level:'B1',text:'Passengers are advised that the 10:30 train to Manchester has been delayed by twenty minutes because of a technical problem. The train is now expected to depart at 10:50. We apologize for the inconvenience.',q:'Why is the train delayed?',options:['Bad weather','A technical problem','A staff meeting'],answer:1,why:'النص يقول because of a technical problem.'},
  {title:'B2 · Remote work',level:'B2',text:'Remote work can improve flexibility and reduce commuting time, but it also requires clear communication. Teams that agree on expectations and document decisions often collaborate more effectively. The best arrangement depends on the nature of the work and the needs of employees.',q:'What helps teams collaborate effectively?',options:['Avoiding written notes','Clear expectations and documented decisions','Longer commutes'],answer:1,why:'النص يذكر الاتفاق على التوقعات وتوثيق القرارات.'},
  {title:'C1 · Evaluating evidence',level:'C1',text:'Although the initial findings appear promising, they should be interpreted cautiously. The sample was relatively small, and the study did not account for every possible confounding factor. Further research across a more diverse population would help determine whether the results can be generalized.',q:'Why should the findings be interpreted cautiously?',options:['The study was never completed','The sample was small and some factors were not considered','The results were not published'],answer:1,why:'ذكر النص صغر العينة وعدم حساب جميع العوامل المحتملة.'}
];
const readingPassages = [
  {title:'A1 · My new hobby',text:'My name is Adam. I started learning photography last month. I take pictures in the park on weekends. I want to learn how to use light and color. My sister sometimes comes with me.',q:'When does Adam take pictures?',options:['Every morning','On weekends','At school'],answer:1,why:'He takes pictures in the park on weekends.'},
  {title:'B1 · Small habits',text:'Many people believe that major changes are necessary to improve their lives. However, small habits can be easier to maintain. Reading for ten minutes, walking daily, or reviewing new vocabulary can produce meaningful progress when repeated consistently.',q:'What is the main idea?',options:['Only major changes work','Small repeated habits can create progress','Reading is unnecessary'],answer:1,why:'الفقرة تؤكد أثر العادات الصغيرة عند تكرارها.'},
  {title:'C1 · Technology and judgment',text:'Automation can improve efficiency, yet efficiency alone is an incomplete measure of success. Decisions about technology should also consider reliability, accountability, accessibility, and unintended consequences. A system that performs quickly but fails unpredictably may create more costs than it saves.',q:'What does the author argue?',options:['Speed is the only useful measure','Technology should be judged by several factors','Automation should never be used'],answer:1,why:'الكاتب يذكر الكفاءة مع عوامل أخرى مثل الموثوقية والمساءلة والآثار غير المقصودة.'}
];
const dailyQuestions = [
  {q:'She _____ to work every day.',opts:['go','goes','going'],a:1,exp:'مع She في المضارع البسيط نضيف s: goes.'},
  {q:'I have lived here _____ 2022.',opts:['for','since','during'],a:1,exp:'since مع نقطة بداية زمنية.'},
  {q:'If it rains, we _____ at home.',opts:['stay','will stay','would stayed'],a:1,exp:'الشرط الأول: if + present, will + base.'},
  {q:'The report _____ yesterday.',opts:['finished','was finished','is finish'],a:1,exp:'مبني للمجهول في الماضي: was finished.'},
  {q:'How _____ information do you need?',opts:['many','much','few'],a:1,exp:'Information غير معدود، لذا much.'},
  {q:'She suggested _____ earlier.',opts:['leave','to leave','leaving'],a:2,exp:'suggest يتبعه غالبًا فعل ing.'},
  {q:'This is the _____ solution of all.',opts:['better','best','good'],a:1,exp:'التفضيل من good هو best.'},
  {q:'By the time we arrived, they _____ .',opts:['left','had left','have leave'],a:1,exp:'الماضي التام للحدث الأسبق.'},
  {q:'_____ the high cost, the project continued.',opts:['Despite','Although','Because'],a:0,exp:'despite يتبعها اسم أو تركيب اسمي.'},
  {q:'The evidence _____ suggest a different outcome.',opts:['may','must to','can to'],a:0,exp:'may + الفعل الأساسي للتعبير عن الاحتمال.'}
];
const starterPrompts = [
  'اشرح لي قاعدة فعل be من الصفر مع أمثلة بسيطة.',
  'اختبرني في المضارع البسيط سؤالًا واحدًا في كل مرة.',
  'تدرّب معي على محادثة التعارف بمستوى A1.',
  'صحح هذه الجملة واشرح الخطأ بالعربية: She go to school every day.',
];

export default function Home() {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'assistant', content: 'أهلًا بك في فلوينت أب! أنا واجهة المعلّم الذكي. اكتب سؤالك أو اختر تمرينًا. لتفعيل الردود الذكية الحقيقية، أضف مفتاح الخدمة إلى ملف البيئة على الخادم كما هو موضح في README.' },
  ]);
  const [input, setInput] = useState('');
  const [busy, setBusy] = useState(false);
  const [status, setStatus] = useState('وضع التطوير — لم يتم ربط خدمة الذكاء الاصطناعي بعد');
  const [voiceStatus, setVoiceStatus] = useState('');
  const [lessonId, setLessonId] = useState(1);
  const [answers, setAnswers] = useState<Record<number, number>>({});
  const [checked, setChecked] = useState(false);
  const [completed, setCompleted] = useState<number[]>([]);
  const [vocabIndex, setVocabIndex] = useState(0);
  const [vocabShow, setVocabShow] = useState(false);
  const [trackIndex, setTrackIndex] = useState(0);
  const [listenAnswer, setListenAnswer] = useState<number | null>(null);
  const [listenChecked, setListenChecked] = useState(false);
  const [readIndex, setReadIndex] = useState(0);
  const [readAnswer, setReadAnswer] = useState<number | null>(null);
  const [readChecked, setReadChecked] = useState(false);
  const [writingText, setWritingText] = useState('');
  const [dailyAnswers, setDailyAnswers] = useState<Record<number, number>>({});
  const [dailyChecked, setDailyChecked] = useState(false);
  const [accountEmail, setAccountEmail] = useState('');
  const [accountPassword, setAccountPassword] = useState('');
  const [accountMessage, setAccountMessage] = useState('');
  const [signedInEmail, setSignedInEmail] = useState('');
  const [accountBusy, setAccountBusy] = useState(false);
  useEffect(() => { try { const saved = localStorage.getItem('fluentup-completed'); if (saved) setCompleted(JSON.parse(saved) as number[]); } catch {} }, []);
  useEffect(() => {
    if (!supabase) return;
    let active = true;
    void supabase.auth.getSession().then(async ({ data }) => {
      if (!active) return;
      const user = data.session?.user;
      if (user) {
        setSignedInEmail(user.email || '');
        const { data: rows } = await supabase.from('learning_progress').select('lesson_id,status').eq('user_id', user.id).eq('status', 'completed');
        if (active && rows) {
          const ids = rows.map((row: {lesson_id:string}) => Number(row.lesson_id)).filter((id: number) => Number.isInteger(id));
          if (ids.length) { setCompleted(prev => Array.from(new Set([...prev, ...ids]))); }
        }
      }
    });
    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => setSignedInEmail(session?.user?.email || ''));
    return () => { active = false; listener.subscription.unsubscribe(); };
  }, []);
  const lesson = allLessons.find(item => item.id === lessonId) || allLessons[0];
  const score = lesson.questions.reduce((total, q, index) => total + (answers[index] === q.answer ? 1 : 0), 0);
  async function markLessonComplete() {
    const next = Array.from(new Set([...completed, lesson.id])); setCompleted(next);
    try { localStorage.setItem('fluentup-completed', JSON.stringify(next)); } catch {}
    if (supabase) {
      const { data } = await supabase.auth.getUser();
      if (data.user) {
        const { error } = await supabase.from('learning_progress').upsert({ user_id: data.user.id, lesson_id: String(lesson.id), status: 'completed', score: Math.round(score / lesson.questions.length * 100), last_activity_at: new Date().toISOString() }, { onConflict: 'user_id,lesson_id' });
        if (error) setAccountMessage('حُفظ التقدم على الجهاز، لكن تعذرت المزامنة السحابية: تحقق من إعداد قاعدة البيانات.');
        else setAccountMessage('تم حفظ تقدمك في حسابك.');
      }
    }
  }
  async function accountAction(action: 'signin' | 'signup' | 'signout') {
    if (!supabase) { setAccountMessage('لتفعيل الحسابات السحابية أضف NEXT_PUBLIC_SUPABASE_URL وNEXT_PUBLIC_SUPABASE_ANON_KEY وشغّل مخطط supabase/schema.sql.'); return; }
    setAccountBusy(true); setAccountMessage('');
    try {
      if (action === 'signout') {
        const { error } = await supabase.auth.signOut(); if (error) throw error;
        setSignedInEmail(''); setAccountMessage('تم تسجيل الخروج.');
      } else {
        if (!accountEmail.trim() || accountPassword.length < 8) { setAccountMessage('أدخل بريدًا صحيحًا وكلمة مرور من 8 أحرف على الأقل.'); return; }
        const result = action === 'signup'
          ? await supabase.auth.signUp({ email: accountEmail.trim(), password: accountPassword })
          : await supabase.auth.signInWithPassword({ email: accountEmail.trim(), password: accountPassword });
        if (result.error) throw result.error;
        setSignedInEmail(result.data.user?.email || accountEmail.trim());
        setAccountMessage(action === 'signup' ? 'تم إنشاء الطلب. قد تحتاج إلى تأكيد البريد الإلكتروني حسب إعدادات Supabase.' : 'تم تسجيل الدخول.');
      }
    } catch (err) { setAccountMessage(err instanceof Error ? err.message : 'تعذر إكمال العملية.'); }
    finally { setAccountBusy(false); }
  }
  const endRef = useRef<HTMLDivElement>(null);
  useEffect(() => endRef.current?.scrollIntoView({ behavior: 'smooth' }), [messages, busy]);

  async function send(text = input) {
    const value = text.trim();
    if (!value || busy) return;
    const next: Message[] = [...messages, { role: 'user', content: value }];
    setMessages(next); setInput(''); setBusy(true); setStatus('جارٍ الاتصال بالخادم…');
    try {
      const response = await fetch('/api/tutor', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ messages: next.filter((m, i) => !(i === 0 && m.role === 'assistant')).slice(-12) }),
      });
      const data = await response.json() as TutorReply;
      if (!response.ok) throw new Error(data.error || 'تعذر إكمال الطلب.');
      setMessages(m => [...m, { role: 'assistant', content: data.reply || 'لم يصل رد نصي.' }]);
      setStatus('تم الرد من الخادم');
    } catch (error) {
      const message = error instanceof Error ? error.message : 'حدث خطأ غير معروف.';
      setMessages(m => [...m, { role: 'assistant', content: `تعذر الحصول على رد ذكي: ${message}\n\nتأكد من تشغيل الخادم وإضافة OPENAI_API_KEY في ملف .env.local. هذه الواجهة لا تدّعي أن الذكاء الاصطناعي متصل قبل إعداد المفتاح.` }]);
      setStatus('لم يكتمل الاتصال');
    } finally { setBusy(false); }
  }

  function startVoice() {
    const w = window as Window & { SpeechRecognition?: new () => SpeechRecognitionLike; webkitSpeechRecognition?: new () => SpeechRecognitionLike };
    const Recognition = w.SpeechRecognition || w.webkitSpeechRecognition;
    if (!Recognition) { setVoiceStatus('التعرف الصوتي غير مدعوم في هذا المتصفح. جرّب متصفحًا يدعمه أو استخدم الكتابة.'); return; }
    const rec = new Recognition(); rec.lang = 'en-US'; rec.interimResults = false; rec.maxAlternatives = 1;
    rec.onresult = event => { const transcript = event.results[0]?.[0]?.transcript || ''; setInput(prev => prev ? `${prev} ${transcript}` : transcript); setVoiceStatus('تم تحويل كلامك إلى نص؛ راجعه ثم اضغط إرسال.'); };
    rec.onerror = () => setVoiceStatus('لم نتمكن من التقاط الصوت. تحقق من إذن الميكروفون.');
    rec.onend = () => {};
    setVoiceStatus('استمع الآن… تحدث بالإنجليزية.'); rec.start();
  }
  function speak(text: string) {
    if (!('speechSynthesis' in window)) { setVoiceStatus('ميزة قراءة النص غير مدعومة في هذا المتصفح.'); return; }
    window.speechSynthesis.cancel(); const utterance = new SpeechSynthesisUtterance(text); utterance.lang = 'en-US'; utterance.rate = 0.92; window.speechSynthesis.speak(utterance);
  }
  return <main className="page">
    <header className="topbar"><a className="brand" href="#top"><span className="logo">F</span><span><b>FluentUp</b><small>فلوينت أب · تعلم بذكاء</small></span></a><nav className="mainNav"><a href="#curriculum">المنهج</a><a href="#skills">المهارات</a><a href="#account">حسابي</a><a href="#vocabulary">المفردات</a><a href="#daily-test">الاختبار</a><a href="#tutor">المعلّم</a></nav><span className="devpill">إصدار شامل تجريبي</span></header>
    <section className="hero" id="top"><div><span className="eyebrow">YOUR ENGLISH JOURNEY STARTS HERE</span><h1>إنجليزيتك، <em>خطوة بخطوة.</em></h1><p>منهج متدرج من A1 إلى C1، والمهارات الأربع، ومفردات واختبارات يومية، مع مساحة مخصصة للمعلّم الذكي.</p><div className="heroActions"><a href="#tutor" className="primary">جرّب المعلّم الذكي ↓</a><a href="#roadmap" className="secondary">خطة بناء المنصة</a></div></div><div className="heroOrb" aria-hidden="true"><span>Ab</span><i>✦</i></div></section>
    <section className="notice"><b>حالة التنفيذ:</b> هذه نسخة تعليمية متكاملة قيد الإعداد. الردود الذكية الحقيقية تتطلب مفتاح API على الخادم، والحسابات والمزامنة السحابية تتطلب إعداد Supabase.</section>
    <section className="section" id="tutor"><div className="sectionHeading"><div><span className="eyebrow dark">AI LANGUAGE COACH</span><h2>معلّمك الذكي</h2><p>اكتب بالعربية أو الإنجليزية، أو ابدأ بأحد التمارين المقترحة.</p></div><span className="status">● {status}</span></div>
      <div className="coach"><aside className="suggestions"><h3>ابدأ من هنا</h3>{starterPrompts.map((p, i) => <button key={p} onClick={() => send(p)} disabled={busy}><span>0{i + 1}</span>{p}</button>)}<div className="voiceCard"><b>🎙️ التدريب الصوتي</b><p>يحوّل المتصفح كلامك إلى نص إذا كان مدعومًا. هذا ليس تقييم نطق متقدمًا.</p><button className="secondary full" onClick={startVoice} disabled={busy}>ابدأ التحدث بالإنجليزية</button>{voiceStatus && <small>{voiceStatus}</small>}</div></aside>
      <div className="chat"><div className="chatHead"><div className="avatar">✦</div><div><b>FluentUp Coach</b><small>معلّم الإنجليزية · وضع التطوير</small></div><button className="speakBtn" onClick={() => speak(messages[messages.length - 1]?.content || '')} aria-label="اقرأ آخر رد بصوت">🔊</button></div><div className="messages" aria-live="polite">{messages.map((m, i) => <div key={i} className={`message ${m.role}`}><small>{m.role === 'assistant' ? 'المعلّم' : 'أنت'}</small><p>{m.content}</p>{m.role === 'assistant' && i > 0 && <button className="inlineSpeak" onClick={() => speak(m.content)}>استمع إلى الرد 🔊</button>}</div>)}{busy && <div className="message assistant"><small>المعلّم</small><p className="dots">يفكر…</p></div>}<div ref={endRef} /></div><form className="composer" onSubmit={e => { e.preventDefault(); void send(); }}><textarea value={input} onChange={e => setInput(e.target.value)} placeholder="اكتب سؤالك أو إجابتك بالإنجليزية…" rows={2} disabled={busy} onKeyDown={e => { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); void send(); } }} /><button className="primary send" disabled={busy || !input.trim()}>{busy ? 'جارٍ الإرسال…' : 'إرسال ↑'}</button></form><div className="chatFoot">لا تضع معلومات شخصية أو كلمات مرور في المحادثة.</div></div></div>
    </section>
    <section className="section" id="curriculum"><div className="sectionHeading"><div><span className="eyebrow dark">A1 → C1 · LEARNING PATH</span><h2>منهجك من الصفر إلى المتقدم</h2><p>منهج متدرج من A1 إلى C1، مع شرح عربي وأمثلة واختبار لكل درس. يُحفظ الإنجاز على هذا الجهاز فقط.</p></div><span className="status">أنجزت {completed.length} من {allLessons.length}</span></div>
      <div className="curriculumLayout"><aside className="lessonList"><div className="lessonListHead"><b>دروس المستوى</b><small>{Math.round(completed.length / allLessons.length * 100)}% مكتمل</small></div><div className="progressTrack"><span style={{width:`${completed.length / allLessons.length * 100}%`}} /></div>{allLessons.map(item => <button key={item.id} className={`lessonPick ${lessonId === item.id ? 'selected' : ''}`} onClick={() => {setLessonId(item.id);setAnswers({});setChecked(false);}}><span className="lessonNumber">{completed.includes(item.id) ? '✓' : String(item.id).padStart(2,'0')}</span><span>{item.title}</span></button>)}</aside>
      <article className="lessonPanel"><div className="lessonKicker">الدرس {String(lesson.id).padStart(2,'0')} · {lesson.level || 'A1'} · {lesson.level === 'C1' ? 'ADVANCED' : lesson.level === 'B2' ? 'UPPER INTERMEDIATE' : lesson.level === 'B1' ? 'INTERMEDIATE' : lesson.level === 'A2' ? 'ELEMENTARY' : 'BEGINNER'}</div><h3>{lesson.title}</h3><p className="lessonGoal"><b>هدف الدرس:</b> {lesson.goal}</p><div className="ruleBox"><b>القاعدة باختصار</b><p>{lesson.rule}</p></div><h4>أمثلة مع المعنى</h4><div className="exampleGrid">{lesson.examples.map(ex => <div className="exampleCard" key={ex.en}><b dir="ltr">{ex.en}</b><span>{ex.ar}</span><button onClick={() => speak(ex.en)}>🔊 استمع</button></div>)}</div><div className="lessonNote"><b>انتبه</b><p>{lesson.note}</p></div><div className="quizHead"><div><span className="eyebrow dark">QUICK CHECK</span><h4>اختبر فهمك</h4></div><small>{lesson.questions.length} سؤال · اختيار من متعدد</small></div>{lesson.questions.map((q, index) => <div className="lessonQuestion" key={q.prompt}><b>{index+1}. {q.prompt}</b><div className="answerOptions">{q.options.map((option, oi) => <label key={option} className={checked && oi === q.answer ? 'correctAnswer' : checked && answers[index] === oi ? 'wrongAnswer' : ''}><input type="radio" name={`q-${lesson.id}-${index}`} checked={answers[index] === oi} disabled={checked} onChange={() => setAnswers(prev => ({...prev,[index]:oi}))}/>{option}</label>)}</div>{checked && <p className="answerExplanation">{answers[index] === q.answer ? '✓ إجابة صحيحة. ' : `الإجابة الصحيحة: ${q.options[q.answer]}. `}{q.explanation}</p>}</div>)}{!checked ? <button className="primary quizSubmit" disabled={Object.keys(answers).length !== lesson.questions.length} onClick={() => setChecked(true)}>تحقق من الإجابات</button> : <div className="quizResult"><b>نتيجتك: {score} / {lesson.questions.length}</b><p>{score === lesson.questions.length ? 'ممتاز! أتقنت هذا الاختبار.' : 'راجع الشرح ثم أعد الاختبار حتى تتأكد من فهمك.'}</p><button className="primary" onClick={() => {if(score >= Math.ceil(lesson.questions.length * 2 / 3)) markLessonComplete(); setAnswers({});setChecked(false);}}>{score >= Math.ceil(lesson.questions.length * 2 / 3) ? (completed.includes(lesson.id) ? 'أعد الاختبار' : 'تسجيل إكمال الدرس وإعادة الاختبار') : 'إعادة المحاولة'}</button>{lesson.id < allLessons.length && <button className="secondary" onClick={() => {setLessonId(lesson.id+1);setAnswers({});setChecked(false);window.document.getElementById('curriculum')?.scrollIntoView({behavior:'smooth'});}}>الدرس التالي ←</button>}</div>}</article></div>
    </section>
    <section className="section" id="account"><div className="sectionHeading"><div><span className="eyebrow dark">YOUR LEARNING PROFILE</span><h2>حسابك وحفظ التقدم</h2><p>يُحفظ تقدمك محليًا دائمًا؛ ويمكن تفعيل المزامنة بين الأجهزة عبر Supabase بعد الإعداد.</p></div></div><div className="accountPanel">{signedInEmail?<><div><b>مسجل الدخول</b><p dir="ltr">{signedInEmail}</p><p>يمكن مزامنة إكمال الدروس في قاعدة البيانات عند إعداد مخطط المشروع.</p></div><button className="secondary" disabled={accountBusy} onClick={()=>void accountAction('signout')}>تسجيل الخروج</button></>:<><div className="accountFields"><label>البريد الإلكتروني<input type="email" autoComplete="email" value={accountEmail} onChange={e=>setAccountEmail(e.target.value)} placeholder="you@example.com"/></label><label>كلمة المرور<input type="password" autoComplete="current-password" value={accountPassword} onChange={e=>setAccountPassword(e.target.value)} placeholder="8 أحرف على الأقل"/></label></div><div className="accountActions"><button className="primary" disabled={accountBusy} onClick={()=>void accountAction('signin')}>تسجيل الدخول</button><button className="secondary" disabled={accountBusy} onClick={()=>void accountAction('signup')}>إنشاء حساب</button></div></>}{accountMessage&&<p className="accountMessage">{accountMessage}</p>}{!supabase&&<p className="skillFoot">الحسابات السحابية غير مفعلة حتى تضيف إعدادات Supabase. لن يُطلب منك إدخال أي مفتاح سري في هذه الصفحة.</p>}</div></section>
    <section className="section" id="skills"><div className="sectionHeading"><div><span className="eyebrow dark">THE FOUR SKILLS</span><h2>تدرّب على المهارات الأربع</h2><p>تدريبات عملية بمحتوى متدرج، مع صوت المتصفح وأسئلة فهم.</p></div></div>
      <div className="skillGrid">
        <article className="skillCard" id="listening"><div className="skillIcon">🎧</div><span className="skillLevel">LISTENING · {listeningTracks[trackIndex].level}</span><h3>الاستماع النشط</h3><p className="skillTitle">{listeningTracks[trackIndex].title}</p><p>استمع للمقطع أكثر من مرة، ثم أجب عن سؤال الفهم. يمكنك إظهار النص بعد المحاولة.</p><div className="skillActions"><button className="primary" onClick={() => speak(listeningTracks[trackIndex].text)}>استمع للمقطع 🔊</button><button className="secondary" onClick={() => {setTrackIndex((trackIndex+1)%listeningTracks.length);setListenAnswer(null);setListenChecked(false);}}>مقطع آخر ←</button></div><div className="listeningTranscript"><b>سؤال الفهم:</b><p>{listeningTracks[trackIndex].q}</p>{listeningTracks[trackIndex].options.map((o,i)=><label key={o} className="skillOption"><input type="radio" name="listen" checked={listenAnswer===i} onChange={()=>{setListenAnswer(i);setListenChecked(false);}}/>{o}</label>)}<button className="secondary" disabled={listenAnswer===null} onClick={()=>setListenChecked(true)}>تحقق</button>{listenChecked&&<p className="skillFeedback">{listenAnswer===listeningTracks[trackIndex].answer?'✓ صحيح! ':'الإجابة الصحيحة: '+listeningTracks[trackIndex].options[listeningTracks[trackIndex].answer]+'. '}{listeningTracks[trackIndex].why}</p>}<details><summary>عرض نص المقطع</summary><p dir="ltr">{listeningTracks[trackIndex].text}</p></details></div></article>
        <article className="skillCard" id="speaking"><div className="skillIcon">🎙️</div><span className="skillLevel">SPEAKING</span><h3>التحدث والمحادثة</h3><p>تدرّب على الإجابة بصوتك. يمكن للمتصفح تحويل كلامك إلى نص إذا كان يدعم التعرف الصوتي؛ بعدها أرسله للمعلّم ليصححه عند تفعيل API.</p><div className="conversationPrompt"><b>مهمة اليوم</b><p dir="ltr">Introduce yourself. Tell me your name, where you live, and why you are learning English.</p><button className="secondary" onClick={()=>speak('Introduce yourself. Tell me your name, where you live, and why you are learning English.')}>استمع للسؤال 🔊</button></div><button className="primary" onClick={startVoice}>ابدأ الإجابة بالميكروفون 🎤</button><p className="skillFoot">ملاحظة: هذا ليس اختبار نطق احترافيًا؛ دقة الميكروفون تعتمد على المتصفح والجهاز.</p><button className="secondary" onClick={()=>{setInput('Please role-play an English introduction conversation with me at A1 level. Ask one question at a time and correct my mistakes in Arabic.');document.getElementById('tutor')?.scrollIntoView({behavior:'smooth'});}}>تدرب مع المعلّم</button></article>
        <article className="skillCard" id="reading"><div className="skillIcon">📖</div><span className="skillLevel">READING</span><h3>القراءة والفهم</h3><p className="skillTitle">{readingPassages[readIndex].title}</p><p className="readingText" dir="ltr">{readingPassages[readIndex].text}</p><b>{readingPassages[readIndex].q}</b>{readingPassages[readIndex].options.map((o,i)=><label className="skillOption" key={o}><input type="radio" name="read" checked={readAnswer===i} onChange={()=>{setReadAnswer(i);setReadChecked(false);}}/>{o}</label>)}<div className="skillActions"><button className="primary" disabled={readAnswer===null} onClick={()=>setReadChecked(true)}>تحقق من الإجابة</button><button className="secondary" onClick={()=>{setReadIndex((readIndex+1)%readingPassages.length);setReadAnswer(null);setReadChecked(false);}}>نص آخر ←</button></div>{readChecked&&<p className="skillFeedback">{readAnswer===readingPassages[readIndex].answer?'✓ إجابة صحيحة. ':'الإجابة: '+readingPassages[readIndex].options[readingPassages[readIndex].answer]+'. '}{readingPassages[readIndex].why}</p>}</article>
        <article className="skillCard" id="writing"><div className="skillIcon">✍️</div><span className="skillLevel">WRITING</span><h3>الكتابة والتصحيح</h3><p>اكتب 3–5 جمل عن يومك أو خططك أو موضوع تختاره. اطلب تصحيحًا تعليميًا يوضح النص الأصلي والمصحح وسبب كل خطأ.</p><label className="writingLabel" htmlFor="writing-text">اكتب فقرتك بالإنجليزية</label><textarea id="writing-text" className="writingArea" value={writingText} onChange={e=>setWritingText(e.target.value)} placeholder="Today I wake up at seven..." rows={6}/><button className="primary" disabled={!writingText.trim()} onClick={()=>{void send('صحح كتابتي الإنجليزية تصحيحًا تعليميًا شاملًا. اعرض النص الأصلي ثم النسخة المصححة، واشرح بالعربية أخطاء القواعد والأزمنة وترتيب الكلمات واختيار المفردات، ثم أعطني تمرينًا قصيرًا. النص: '+writingText);document.getElementById('tutor')?.scrollIntoView({behavior:'smooth'});}}>أرسل للمعلّم لتصحيحها</button><p className="skillFoot">التصحيح الذكي يحتاج مفتاح API صالحًا وإعداد الخادم.</p></article>
      </div>
    </section>
    <section className="section" id="vocabulary"><div className="sectionHeading"><div><span className="eyebrow dark">DAILY VOCABULARY</span><h2>بطاقات المفردات</h2><p>{vocabulary.length} كلمة عملية مع معنى ومثال، للتدرب على التذكر النشط.</p></div><span className="status">الكلمة {vocabIndex+1} / {vocabulary.length}</span></div><div className="vocabPanel"><div className="vocabTop"><span>WORD CARD</span><span>راجع المعنى ثم المثال</span></div><div className="vocabWord" dir="ltr">{vocabulary[vocabIndex][0]}</div>{vocabShow?<><div className="vocabMeaning">{vocabulary[vocabIndex][1]}</div><p className="vocabExample" dir="ltr">{vocabulary[vocabIndex][2]}</p><button className="secondary" onClick={()=>speak(vocabulary[vocabIndex][0]+'. '+vocabulary[vocabIndex][2])}>استمع 🔊</button></>:<button className="primary" onClick={()=>setVocabShow(true)}>اكشف المعنى</button>}<div className="vocabActions"><button className="secondary" onClick={()=>{setVocabIndex((vocabIndex-1+vocabulary.length)%vocabulary.length);setVocabShow(false);}}>← السابقة</button><button className="primary" onClick={()=>{setVocabIndex((vocabIndex+1)%vocabulary.length);setVocabShow(false);}}>عرفتها، التالية →</button></div></div></section>
    <section className="section" id="daily-test"><div className="sectionHeading"><div><span className="eyebrow dark">DAILY CHECK</span><h2>الاختبار اليومي</h2><p>10 أسئلة مختلطة من القواعد والمفردات. أجب عنها كلها ثم اعرض نتيجتك.</p></div></div><div className="dailyQuiz">{dailyQuestions.map((q,i)=><div className="dailyQuestion" key={q.q}><b>{i+1}. {q.q}</b><div className="dailyOptions">{q.opts.map((o,j)=><label key={o} className={dailyChecked&&j===q.a?'correctAnswer':dailyChecked&&dailyAnswers[i]===j?'wrongAnswer':''}><input type="radio" name={'daily-'+i} checked={dailyAnswers[i]===j} disabled={dailyChecked} onChange={()=>setDailyAnswers(prev=>({...prev,[i]:j}))}/>{o}</label>)}</div>{dailyChecked&&<p className="answerExplanation">{dailyAnswers[i]===q.a?'✓ صحيح. ':'الإجابة الصحيحة: '+q.opts[q.a]+'. '}{q.exp}</p>}</div>)}{!dailyChecked?<button className="primary" disabled={Object.keys(dailyAnswers).length!==dailyQuestions.length} onClick={()=>setDailyChecked(true)}>اعرض نتيجتي</button>:<div className="quizResult"><b>نتيجتك: {dailyQuestions.filter((q,i)=>dailyAnswers[i]===q.a).length} / {dailyQuestions.length}</b><p>راجع تفسير كل إجابة، ثم أعد الاختبار لترسيخ القواعد.</p><button className="primary" onClick={()=>{setDailyAnswers({});setDailyChecked(false);}}>أعد الاختبار</button></div>}</div></section>
    <section className="section" id="roadmap"><div className="sectionHeading"><div><span className="eyebrow dark">BUILD IN MILESTONES</span><h2>حالة المشروع قبل الإطلاق</h2><p>هذه نسخة MVP موسعة؛ الميزات الخارجية تحتاج إعدادًا واختبارًا قبل النشر العام.</p></div></div><div className="milestones"><article className="milestone current"><span>01</span><div><b>واجهة المنصة ومحتوى التعلم</b><p>واجهة عربية، 50 درسًا، المهارات الأربع، مفردات واختبار يومي.</p></div><label>موجود</label></article><article className="milestone"><span>02</span><div><b>مراجعة المحتوى وتوسيعه</b><p>مراجعة تربوية لكل إجابة وتوسيع الاستماع والقراءة والمفردات والتكرار المتباعد.</p></div><label>قبل الإطلاق</label></article><article className="milestone"><span>03</span><div><b>الحسابات والمزامنة</b><p>واجهة Supabase موجودة؛ يلزم إنشاء المشروع وضبط البيئة واختبار سياسات الوصول.</p></div><label>إعداد مطلوب</label></article><article className="milestone"><span>04</span><div><b>الذكاء الاصطناعي والصوت</b><p>نقطة API خادمية ومحادثة نصية جاهزة للربط؛ الميكروفون والصوت يعتمدان على المتصفح ومزود الخدمة.</p></div><label>مفتاح مطلوب</label></article><article className="milestone"><span>05</span><div><b>النشر العام وتطبيق iPhone</b><p>لم يتم النشر. يلزم اختبار البناء والأمان والتكلفة والخصوصية، ثم الاستضافة وتجهيز iOS.</p></div><label>لم يكتمل</label></article></div></section>
    <footer>FluentUp © 2026 · حزمة ويب قيد التجهيز · لم يتم النشر بعد · بعض الخدمات تحتاج مفاتيح وإعدادات خارجية</footer>
  </main>;
}

type SpeechRecognitionLike = {
  lang: string; interimResults: boolean; maxAlternatives: number;
  onresult: ((event: { results: ArrayLike<ArrayLike<{ transcript: string }>> }) => void) | null;
  onerror: (() => void) | null; onend: (() => void) | null; start: () => void;
};
