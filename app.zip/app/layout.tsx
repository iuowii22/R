import type { Metadata } from 'next';
import './globals.css';
export const metadata: Metadata = {
  title: 'FluentUp | فلوينت أب',
  description: 'منصة عربية لتعلم الإنجليزية من الصفر، مع معلم ذكي ومسار تعلم شخصي.',
  applicationName: 'FluentUp',
};
export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="ar" dir="rtl"><body>{children}</body></html>;
}
