-- Optional next milestone: run in Supabase SQL editor after creating a project.
create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  target_level text not null default 'A1' check (target_level in ('A1','A2','B1','B2','C1')),
  daily_goal_minutes integer not null default 20 check (daily_goal_minutes between 5 and 240),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table if not exists public.learning_progress (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  lesson_id text not null,
  status text not null default 'started' check (status in ('started','completed','review')),
  score numeric(5,2) check (score between 0 and 100),
  attempts integer not null default 0 check (attempts >= 0),
  last_activity_at timestamptz not null default now(),
  unique(user_id, lesson_id)
);

create table if not exists public.vocabulary_reviews (
  id bigint generated always as identity primary key,
  user_id uuid not null references auth.users(id) on delete cascade,
  word_id text not null,
  next_review_at timestamptz not null default now(),
  interval_days integer not null default 1 check (interval_days >= 1),
  ease_factor numeric(4,2) not null default 2.50 check (ease_factor between 1.30 and 4.00),
  last_quality integer check (last_quality between 0 and 5),
  unique(user_id, word_id)
);

alter table public.profiles enable row level security;
alter table public.learning_progress enable row level security;
alter table public.vocabulary_reviews enable row level security;

create policy "Users can view own profile" on public.profiles for select using (auth.uid() = id);
create policy "Users can insert own profile" on public.profiles for insert with check (auth.uid() = id);
create policy "Users can update own profile" on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);
create policy "Users manage own learning progress" on public.learning_progress for all using (auth.uid() = user_id) with check (auth.uid() = user_id);
create policy "Users manage own vocabulary reviews" on public.vocabulary_reviews for all using (auth.uid() = user_id) with check (auth.uid() = user_id);

create or replace function public.create_profile_for_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, display_name) values (new.id, coalesce(new.raw_user_meta_data->>'name', '')) on conflict (id) do nothing;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.create_profile_for_new_user();
